const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

const alunosDaTurma = ["Anifa", "Cariza", "Cintia", "Kemelly", "Maria", "Natanael", "Ruben", "Wilza"]

app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/turma', (req, res) => {
    const alunosList = alunosDaTurma.map(aluno => `<li>${aluno}</li>`).join('');
    const html = `
        <html>
            <body>
                <h1>Lista de Alunos da Turma</h1>
                <ul>${alunosList}</ul>
            </body>
        </html>
    `;
    res.send(html);
});

app.use((req, res) => {
    console.log("Continuando processando http request");
    res.send('<h1>Olá de servidor web com Express!</h1>')
});

app.get('/inscrever', (req, res) => {
    const form = `
        <html>
            <body>
                <h1>Inscreva-se na Turma WebServices</h1>
                <form action="/adicionarNaTurma" method="post">
                    <label for="aluno">Nome do Aluno:</label>
                    <input type="text" id="aluno" name="aluno">
                    <input type="submit" value="Adicionar na Turma">
                </form>
            </body>
        </html>
    `;
    res.send(form);
});

app.post('/adicionarNaTurma', (req, res) => {
    const aluno = req.body.aluno;
    console.log(`Aluno '${aluno}' foi adicionado à turma!`);
    res.send("Aluno adicionado com sucesso.");
});

// Método PUT para atualizar um aluno na lista
app.put('/atualizarAluno/:aluno', (req, res) => {
    const alunoAntigo = req.params.aluno;
    const novoAluno = req.body.aluno;
    
    // proxima aula atualizar aluno na lista
    
    console.log(`Aluno '${alunoAntigo}' foi atualizado para '${novoAluno}'`);
    res.send("Aluno atualizado com sucesso.");
});

// Método DELETE para remover um aluno da lista
app.delete('/removerAluno/:aluno', (req, res) => {
    const aluno = req.params.aluno;
    
    // proxima aula logica para remover aluno da lista
    
    console.log(`Aluno '${aluno}' foi removido da turma!`);
    res.send("Aluno removido com sucesso.");
});

app.listen(port, () => {
    console.log(`Servidor está rodando em http://localhost:${port}`);
});
